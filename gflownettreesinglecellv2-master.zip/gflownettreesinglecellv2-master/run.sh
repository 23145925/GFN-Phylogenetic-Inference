# CUDA_VISIBLE_DEVICES=0 nohup python train.py \
# /root/yangshenzhi/phylogfn-main/src/configs/benchmark_dna_cfgs/discrete_branch_lengths/stem_cfg_0.001binsize_50bins_temperature_anneal_0.4.yaml \
# /root/yangshenzhi/phylogfn-main/output/datasets/stem-cell_500-4.pickle \
# /root/yangshenzhi/phylogfn-main/output >> run-stem-cell.log 2>&1 &


# CUDA_VISIBLE_DEVICES=0 python train.py \
# /root/yangshenzhi/phylogfn-main/src/configs/benchmark_dna_cfgs/discrete_branch_lengths/stem_cfg_0.001binsize_50bins_temperature_anneal_0.4.yaml \
# /root/yangshenzhi/phylogfn-main/output/datasets/stem-cell_500-4.pickle \
# /root/yangshenzhi/phylogfn-main/output


CUDA_VISIBLE_DEVICES=0 nohup python train.py \
/root/yangshenzhi/stem/src/configs/benchmark_dna_cfgs/discrete_branch_lengths/stem_cfg_0.001binsize_50bins_temperature_anneal_0.4.yaml \
/root/yangshenzhi/stem/output/datasets/stem-cell_500.pickle \
/root/yangshenzhi/stem/output >> run-stem-cell-13.log 2>&1 &


