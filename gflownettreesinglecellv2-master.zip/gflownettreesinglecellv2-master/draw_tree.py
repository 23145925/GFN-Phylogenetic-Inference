import pickle
from Bio import Phylo
import matplotlib.pyplot as plt
from ete3 import Tree, TreeStyle



# 加载 pkl 文件
with open('/root/yangshenzhi/stem/20241020_211021_output/best_trees.pt', 'rb') as file:
    data = pickle.load(file)


with open('/root/yangshenzhi/phylogfn-main/output/cluster_mean_name-500.pickle', 'rb') as file:
    cluster_name = pickle.load(file)
# 查看加载的数据
# print(data[-1])
print(data[-1].ete_node)
# 获取 ete_node
ete_node = data[0].ete_node
for i in range(53):
    node = ete_node.search_nodes(name = i)[0]
    if node:
        node.name = cluster_name[str(i)]
# for node in ete_node.traverse():
#     print(node.name)
#     print(type(node.name))

# 创建树的风格
ts = TreeStyle()
ts.show_leaf_name = True  # 显示叶节点名称
ts.mode = "r"  # 设置为圆形树或其他模式

# # 绘制进化树
# ete_node.show(tree_style=ts)

# 保存为图片（可选）
ete_node.render("/root/yangshenzhi/stem/figures/phylogenetic_tree-r.png", tree_style=ts, dpi=300)


