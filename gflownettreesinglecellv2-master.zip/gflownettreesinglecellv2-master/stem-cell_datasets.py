import scanpy as sc
import numpy as np
import pandas as pd
import pickle
def load_raw_data():
    adata = sc.read_h5ad('/root/yangshenzhi/phylogfn-main/dataset/Spanjaard_2018_NatureBiotechnology.h5ad')
    X = adata.X
    # 查看基本信息
    print(X)
    return adata, X
def raw_data_preprocess():

    # 读取 .h5ad 文件
    adata = sc.read_h5ad('/root/yangshenzhi/phylogfn-main/dataset/Spanjaard_2018_NatureBiotechnology.h5ad')
    X = adata.X
    # 查看基本信息
    print(X.shape)

    # 对每个细胞进行归一化，使总的基因表达值为1万
    sc.pp.normalize_total(adata, target_sum=1e4)

    # 对数据进行对数变换
    sc.pp.log1p(adata) #可能不需要

    # 识别最具变异性的基因
    sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5,n_top_genes=500)#几百个

    # 只保留高变基因用于后续分析
    adata = adata[:, adata.var['highly_variable']]

    # 对数据进行标准化，使每个基因的平均表达为0，标准差为1
    sc.pp.scale(adata, max_value=10)

    # 计算主成分
    sc.tl.pca(adata, svd_solver='arpack')

    # 查看解释的方差比例
    sc.pl.pca_variance_ratio(adata, log=True)

    # 计算最近邻图，基于PCA的前几个成分（n_pcs 参数）
    sc.pp.neighbors(adata, n_neighbors=10, n_pcs=40)


    # 使用 Louvain 聚类
    sc.tl.louvain(adata)

    # 如果想要使用 Leiden 聚类，可以替换为：
    # sc.tl.leiden(adata)


    # 计算 UMAP
    sc.tl.umap(adata)

    # 如果想使用 t-SNE，可替换为：
    # sc.tl.tsne(adata)

    # 可视化 UMAP 聚类结果
    sc.pl.umap(adata, color=['louvain'])  # 或使用 'leiden' 作为聚类结果

    # 保存包含聚类结果和降维坐标的 AnnData 对象
    # adata.write('/root/yangshenzhi/phylogfn-main/output/processed_data_with_clusters_500.h5ad')



def load_processed_data():
    adata = sc.read_h5ad('/root/yangshenzhi/phylogfn-main/output/processed_data_with_clusters_500.h5ad')
    print(adata)
    return adata

def load_clusters_data(path = None):
    cluster = pd.read_pickle(path)
    print(type(cluster))
    return cluster

def load_phylo_datasets(path):
    data = pickle.load(open(path, 'rb'))
    print(type(data))
    for i in data:
        print(i)

    print(data['Alligator_mississippiensis'])

def feature_discretization(feature):
    MAX = feature.max().max() + 1
    MIN = feature.min().min() - 1

    bins = [i for i in range(int(MIN), int(MAX)+1)]
    print(bins)
    labels =['A', 'B', 'C', 'D', 'E','F','G','H','I','J','K','L','M']

    discretization = feature.applymap(lambda x: pd.cut([x], bins=bins, labels=labels)[0])
    print(discretization)
    print(type(discretization['si:dkey-61f9.2'][1]))
    print(discretization.shape)

    return discretization


def feature_discretization_qcut(feature):
    MAX = feature.max().max() + 1
    MIN = feature.min().min() - 1

    bins = [i for i in range(int(MIN), int(MAX)+1)]
    print(bins)
    labels =['A', 'G', 'C', 'T']

    feature1 = feature.values.flatten()  # 展平为一维数组
    discretization = pd.qcut(feature1, 4, labels=labels)  # 四分位数分箱
    df_binned  = pd.DataFrame(discretization.reshape(feature.shape), columns=feature.columns)
    print(df_binned )
    print(type(df_binned ['si:dkey-61f9.2'][1]))
    print(df_binned .shape)

    return df_binned 

def discretize2sequence(discretization):
    sequences = discretization.apply(lambda row: ''.join(row.astype(str)), axis=1)
    sq = {}
    for i, n in enumerate(sequences):
        sq[i] = n
    print(sq)
    with open('/root/yangshenzhi/phylogfn-main/output/datasets/stem-cell_500-4.pickle','wb') as f:
        pickle.dump(sq,f)
    return sq


def load_stem_cell(path):
    dict_species_seq = pickle.load(open(path, 'rb'))
    all_seqs = list(dict_species_seq.values())
    print(all_seqs)
    for i in all_seqs:
        print(i.find('D'))





def visual_umap(adata):
    sc.pl.umap(adata, color=['louvain'],save='louvain_clusters.png')


def get_clusters_mean_louvain(adata):
    cluster_means = adata.to_df().groupby(adata.obs['louvain']).mean()
    print(cluster_means.shape)
    cluster_means.to_pickle('/root/yangshenzhi/phylogfn-main/output/clusters_mean_500.pkl')
    # sc.pl.heatmap(adata, var_names=['mansc1', 'dpysl5b', 'si:ch211-152c2.3', 'naga', 'ptn'], groupby='louvain',save='louvain_clusters_mean_500.png')
    return cluster_means

if __name__ == '__main__':
    # cluster = load_clusters_data("/root/yangshenzhi/phylogfn-main/output/clusters_mean_500.pkl")
    # fd = feature_discretization_qcut(cluster)
    # sq = discretize2sequence(fd)


    # phylo_data = load_phylo_datasets('/root/yangshenzhi/phylogfn-main/dataset/benchmark_datasets/DS1.pickle')

    data = load_stem_cell('/root/yangshenzhi/phylogfn-main/output/datasets/stem-cell_500-4.pickle')
